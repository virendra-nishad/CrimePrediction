Programming language used :

	python3
	
	Packages:
		- numpy
		- pandas
		- matplotlib
		- sklearn
		


predict.sh shell script can be used to run the entire program

OUTPUT :
    - After running above script following results will be generated
	- Plot of crimes at country level will be geberated and saved in folder yearly-crime-plot
	- Prediction of crimes for year 2001 will be generated in form of csv file
	

File and Folder organisation :
	- Code_and_Data: This folder contains all data and code required to run prediction
	
